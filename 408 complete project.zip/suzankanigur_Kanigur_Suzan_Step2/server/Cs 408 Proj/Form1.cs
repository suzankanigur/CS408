using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Threading;
using System.IO;
using Cs_408_Proj.Utils;




namespace Cs_408_Proj
{
    public partial class Form1 : Form
    {
        //Variables
      
        private static Dictionary<TcpClient, double> _scores = new Dictionary<TcpClient, double>();
        private static Dictionary<TcpClient, int> _player_answers = new Dictionary<TcpClient, int>();
        private static Dictionary<TcpClient, string> _usernames;
        private static List<string> _questions;
        private static List<int> _answers;
        private List<TcpClient> _clients;
        private TcpListener _listener = default!;
        private int _clientCount;
        private bool _keep_going;
        private int _port;
        private int waiting = 0;




        public Form1()
        {
            InitializeComponent();
            _clients = new List<TcpClient>();
            _usernames = new Dictionary<TcpClient, string>();
            questionBox.Text = "0";
            _startServerButton.Enabled= true;
            _stopServerButton.Enabled= false;
            _statusBox.Text = string.Empty;
            



        }
        //Button functions

        #region Event Handlers

        //Starts server when button pressed
        private void StartServerButtonHandler(object sender, EventArgs e)
        {
           
            _clientCount = 0;
            _conncectedClientsBox.Text = _clientCount.ToString();
            _statusBox.Text = string.Empty;
            IPAddress ip = GetLocalIPAddress();
            _ipBox.Text = ip.ToString();

            try
            {
                if(!Int32.TryParse(_portBox.Text, out _port))
                {
                    _port = 100;
                    _statusBox.Text += "\r\n Wrong Port, Server Starting at Port Number 100!";

                }

                Thread t = new Thread(ListenForIncomingConnections);//Connection thread created
                t.Name = "Server Listener Thread";
                t.IsBackground= true;
                t.Start();//Connection thread started

                _startServerButton.Enabled = false;
                _stopServerButton.Enabled = true;

            }
            catch(Exception ex)
            {
                _statusBox.Text += "\r\nProblem starting Server";
                _statusBox.Text += "\r\n" + ex.ToString();
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void _connectedClientsLabel_Click(object sender, EventArgs e)
        {

        }

        //Stops server when button pressed
        private void StopServerButtonHandler(object sender, EventArgs e)
        {
            _keep_going= false;
            _statusBox.Text = string.Empty;
            _statusBox.Text = "Shutting Down Server, Disconnecting all clients!";

            try
            {
                foreach(TcpClient client in _clients)
                {
                    client.Close();
                    _clientCount--;
                    _conncectedClientsBox.Text = _clientCount.ToString();
                }
                _clients.Clear();
                _listener.Stop();

            }catch(Exception ex) {

                _statusBox.Text += "\r\nProblem Shutting Down Server!\r\n " + ex.ToString();

            }
            _startServerButton.Enabled = true;
            _stopServerButton.Enabled = false;


        }





        #endregion

        //Gets the local ip address
        public static IPAddress GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {

                    return ip;
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system!");
        }

        //Looks out for incoming connections
        private void ListenForIncomingConnections()
        {
            try
            {
                _keep_going = true;
                _listener = new TcpListener(IPAddress.Any, _port);
                _listener.Start();
                _statusBox.InvokeEx(stb => stb.Text += "\r\nServer Started, listening on port: " + _port.ToString());
                

                while (_keep_going)
                {
                    _statusBox.InvokeEx(stb => stb.Text += "\r\nWaiting for incoming client connections...");
                    TcpClient client = _listener.AcceptTcpClient();
                    _statusBox.InvokeEx(stb => stb.Text += "\r\nClient Accepted");

                    Thread t = new Thread(ProcessClientReq);
                    t.IsBackground = true;
                    t.Start(client);

                }

            }
            catch (SocketException se)
            {

            }
            catch (Exception ex)
            {
                _statusBox.InvokeEx(stb => stb.Text += ex.ToString());

            }
        }

        //Looks out for incoming client messages and possible disconnections
        private void ProcessClientReq(object tcpClient)
        {
            TcpClient client = (TcpClient)tcpClient;



            bool flag = true;
            string input = string.Empty;
            string message = string.Empty;
            int check = 9;

            try
            {
                StreamReader reader = new StreamReader(client.GetStream());
                StreamWriter writer= new StreamWriter(client.GetStream());

                _clients.Add(client);
                _clientCount++;
                _conncectedClientsBox.InvokeEx(ccb => ccb.Text = _clientCount.ToString());


                while (client.Connected)
                {
                    input = reader.ReadLine();
                    if (input == null) { break; }
                   
                    
                 
                    message = input[1..].Trim();
                    check = int.Parse(input.Substring(0,1));
                    

                   
                    
                    if (_usernames.ContainsValue(message.Split(' ').ToList()[0]) && flag){
                        _statusBox.InvokeEx(stb => stb.Text += "\r\nConnection Attempt With Existing Username");
                        writer.WriteLine("Username already taken.");
                        writer.Flush();
                        break;
                    }
                    
                    if (flag)
                    {
                        _usernames[client] = message.Split(' ').ToList()[0];
                        
                    }

                    flag = false;







                    switch (check)
                    {

                        
                        //TODO bariyer ayari
                        case 1:
                            {
                                if (_scores.ContainsKey(client)) {
                                    _player_answers[client] = int.Parse(message);
                                    _statusBox.InvokeEx(stb => stb.Text += "\r\n" + _usernames[client] + " Answered: " + message);
                                    writer.WriteLine("Server Recieved: " + message);
                                    writer.Flush();
                                    waiting++;
                                }
                                else
                                {
                                    writer.WriteLine("Game in progress.");
                                    writer.Flush();

                                }

                                break;


                            }
                        default:
                            {

                                _statusBox.InvokeEx(stb => stb.Text += "\r\n" + _usernames[client] + " : " + message);
                                writer.WriteLine("Server Recieved: " + message);
                                writer.Flush();
                                
                                break;


                            }



                    }
                }
                

            }catch(SocketException sx) 
            {
                _statusBox.InvokeEx(stb => stb.Text += "\r\nProblem processing client response!\r\n" + sx.ToString());
            }
            catch(Exception ex)
            {
                _statusBox.InvokeEx(stb => stb.Text += "\r\nProblem processing client response!\r\n" + ex.ToString());
            }


            if (!flag)
            {
                _statusBox.InvokeEx(stb => stb.Text += "\r\nClient Disconnected :" + _usernames[client]);

            }
            
            _scores.Remove(client);            
            _usernames.Remove(client);
            _clients.Remove(client);
            

            _clientCount--;
            _conncectedClientsBox.InvokeEx(ccb => ccb.Text = _clientCount.ToString());
            
        }

        //Sends one question to all clients
        private void SendQuestion(object tcpClient,String question)
        {


            TcpClient client = (TcpClient)tcpClient;
            try
            {
                

                StreamWriter writer = new StreamWriter(client.GetStream());
                writer.WriteLine("Question:");
                writer.Flush();
                writer.WriteLine(question);
                writer.Flush();

                

            }
            catch(Exception ex)
            {
                _statusBox.InvokeEx(stb => stb.Text += "\r\nProblem sending Question to client : \r\n"+ ex.ToString());
            }

        }

        private void SendScores(object tcpClient)
        {


            TcpClient client = (TcpClient)tcpClient;
            try
            {
                


                
                StreamWriter writer = new StreamWriter(client.GetStream());

                foreach (var score in _scores)
                {
                    writer.WriteLine(_usernames[score.Key] + ": " + score.Value.ToString());

                }
                    
                writer.Flush();
                  
                   
                




            }
            catch (Exception ex)
            {
                _statusBox.InvokeEx(stb => stb.Text += "\r\nProblem sendig Scores to client : \r\n" + ex.ToString());
            }

        }

        private void CalculateScores(int qNum)
        {


            try
            {
                List<TcpClient> player_names = new List<TcpClient>();
                List<int> player_scores = new List<int>();
                

                int answer = _answers[qNum];
                foreach (var score in _player_answers)
                {
                    int temp = answer - score.Value;
                    if(temp < 0)
                    {
                        temp = temp * -1;
                    }
                    if(player_names.Count() == 0)
                    {
                        player_names.Add(score.Key);
                        player_scores.Add(temp);
                    }
                    else
                    {
                        if (player_scores[0] == temp)
                        {
                            player_names.Add(score.Key);
                            player_scores.Add(temp);
                        }
                        else if(player_scores[0] > temp)
                        {
                            player_names = new List<TcpClient>();
                            player_scores = new List<int>();
                            player_names.Add(score.Key);
                            player_scores.Add(temp);
                        }

                    }

                }
               
                int num = player_names.Count();
                foreach (var client in player_names)
                {
                    _scores[client] += (1.0 / num);
                }


            }
            catch (Exception ex)
            {
                _statusBox.InvokeEx(stb => stb.Text += "\r\nProblem sendig Scores to client : \r\n" + ex.ToString());
            }

        }

        private void SendEndGameScores(object tcpClient)
        {



            TcpClient client = (TcpClient)tcpClient;
            try
            {




                StreamWriter writer = new StreamWriter(client.GetStream());
                writer.WriteLine("Total Scores:");
                writer.Flush();

                foreach (var score in _scores)
                {
                    writer.WriteLine(_usernames[score.Key] + ": " + score.Value.ToString());

                }

                writer.Flush();



            }
            catch (Exception ex)
            {
                _statusBox.InvokeEx(stb => stb.Text += "\r\nProblem sendig Scores to client : \r\n" + ex.ToString());
            }

        }

        private void StartGame()
        {
           
            _scores = new Dictionary<TcpClient, double>();
            _questions = new List<string>();
            _answers = new List<int>();

            foreach (TcpClient key in _usernames.Keys)
            {
                
                _scores.Add(key, 0.0);
            }
            
            
            string[] lines = File.ReadAllLines(@"C:\Users\user\Desktop\408 last\questions.txt");


            for (int i = 0; i < lines.Length - 1; i += 2)
            {                _questions.Add(lines[i]);
                             _answers.Add(int.Parse(lines[i + 1]));
            }
            _statusBox.InvokeEx(stb => stb.Text += "\r\nGame Started \r\n");
            foreach (var player in _scores)
            {
                StreamWriter writer = new StreamWriter(player.Key.GetStream());
                writer.WriteLine("Game Started");
                writer.Flush();
            }
            

            try
            {

                int remainingQuestions = int.Parse(questionBox.Text);
                int qNum = 0;
                while (remainingQuestions > 0)
                {
                    _player_answers = new Dictionary<TcpClient, int>();
                    waiting = 0;
                    foreach (var player in _scores)
                    {
                        SendQuestion(player.Key, _questions[qNum]);

                        
                    }

                    while (waiting < _scores.Count()) ;



                    CalculateScores(qNum);

                    foreach (var player in _scores)
                    {
                        SendScores(player.Key);
                    }
                    qNum++;
                    remainingQuestions--;
                    if (qNum == _questions.Count)
                    {
                        qNum = 0;
                    }
                }

                _statusBox.InvokeEx(stb => stb.Text += "\r\nGame Ended \r\n");
                foreach (var player in _scores)
                {
                    StreamWriter writer = new StreamWriter(player.Key.GetStream());
                    writer.WriteLine("Game Ended");
                    writer.Flush();
                }

                


                foreach (var player in _scores)
                {
                    SendEndGameScores(player.Key);
                }


            }
            catch (SocketException se)
            {

            }
            catch (Exception ex)
            {
                _statusBox.InvokeEx(stb => stb.Text += ex.ToString());

            }


        }

        private void _connectedClientsBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void startGameButton_Click(object sender, EventArgs e)
        {

            Thread t = new Thread(StartGame);
            t.IsBackground = true;
            t.Start();
        }
    }
}