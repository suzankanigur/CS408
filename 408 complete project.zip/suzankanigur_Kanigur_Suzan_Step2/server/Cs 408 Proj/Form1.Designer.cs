﻿namespace Cs_408_Proj
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this._ipLabel = new System.Windows.Forms.Label();
            this._connectedClientsLabel = new System.Windows.Forms.Label();
            this._conncectedClientsBox = new System.Windows.Forms.TextBox();
            this._questionNumberLabel = new System.Windows.Forms.Label();
            this.questionBox = new System.Windows.Forms.TextBox();
            this._ipBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.startGameButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this._startServerButton = new System.Windows.Forms.Button();
            this._stopServerButton = new System.Windows.Forms.Button();
            this._portLabel = new System.Windows.Forms.Label();
            this._portBox = new System.Windows.Forms.TextBox();
            this._statusBox = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this._statusBox, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(914, 600);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this._ipLabel, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this._connectedClientsLabel, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this._conncectedClientsBox, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this._questionNumberLabel, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.questionBox, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this._ipBox, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.startGameButton, 1, 4);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(460, 4);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 131F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(451, 292);
            this.tableLayoutPanel2.TabIndex = 0;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // _ipLabel
            // 
            this._ipLabel.AutoSize = true;
            this._ipLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._ipLabel.Location = new System.Drawing.Point(3, 124);
            this._ipLabel.Name = "_ipLabel";
            this._ipLabel.Size = new System.Drawing.Size(219, 36);
            this._ipLabel.TabIndex = 5;
            this._ipLabel.Text = "IP Address:";
            this._ipLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this._ipLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // _connectedClientsLabel
            // 
            this._connectedClientsLabel.AutoSize = true;
            this._connectedClientsLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._connectedClientsLabel.Location = new System.Drawing.Point(3, 0);
            this._connectedClientsLabel.Name = "_connectedClientsLabel";
            this._connectedClientsLabel.Size = new System.Drawing.Size(219, 35);
            this._connectedClientsLabel.TabIndex = 0;
            this._connectedClientsLabel.Text = "Connected Clients :";
            this._connectedClientsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this._connectedClientsLabel.Click += new System.EventHandler(this._connectedClientsLabel_Click);
            // 
            // _conncectedClientsBox
            // 
            this._conncectedClientsBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._conncectedClientsBox.Location = new System.Drawing.Point(228, 4);
            this._conncectedClientsBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this._conncectedClientsBox.Name = "_conncectedClientsBox";
            this._conncectedClientsBox.ReadOnly = true;
            this._conncectedClientsBox.Size = new System.Drawing.Size(220, 27);
            this._conncectedClientsBox.TabIndex = 1;
            this._conncectedClientsBox.Text = "0";
            this._conncectedClientsBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this._conncectedClientsBox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // _questionNumberLabel
            // 
            this._questionNumberLabel.AutoSize = true;
            this._questionNumberLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._questionNumberLabel.Location = new System.Drawing.Point(3, 87);
            this._questionNumberLabel.Name = "_questionNumberLabel";
            this._questionNumberLabel.Size = new System.Drawing.Size(219, 37);
            this._questionNumberLabel.TabIndex = 4;
            this._questionNumberLabel.Text = "The # of questions in a game:";
            this._questionNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // questionBox
            // 
            this.questionBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.questionBox.Location = new System.Drawing.Point(228, 91);
            this.questionBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.questionBox.Name = "questionBox";
            this.questionBox.Size = new System.Drawing.Size(220, 27);
            this.questionBox.TabIndex = 3;
            this.questionBox.Text = "5";
            this.questionBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.questionBox.TextChanged += new System.EventHandler(this._connectedClientsBox_TextChanged);
            // 
            // _ipBox
            // 
            this._ipBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._ipBox.Location = new System.Drawing.Point(228, 128);
            this._ipBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this._ipBox.Name = "_ipBox";
            this._ipBox.ReadOnly = true;
            this._ipBox.Size = new System.Drawing.Size(220, 27);
            this._ipBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 20);
            this.label1.TabIndex = 7;
            // 
            // startGameButton
            // 
            this.startGameButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.startGameButton.Location = new System.Drawing.Point(228, 228);
            this.startGameButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.startGameButton.Name = "startGameButton";
            this.startGameButton.Size = new System.Drawing.Size(220, 60);
            this.startGameButton.TabIndex = 8;
            this.startGameButton.Text = "Start Game";
            this.startGameButton.UseVisualStyleBackColor = true;
            this.startGameButton.Click += new System.EventHandler(this.startGameButton_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this._startServerButton, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this._stopServerButton, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this._portLabel, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this._portBox, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(460, 304);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83.24324F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.75676F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(451, 292);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // _startServerButton
            // 
            this._startServerButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this._startServerButton.Location = new System.Drawing.Point(228, 251);
            this._startServerButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this._startServerButton.Name = "_startServerButton";
            this._startServerButton.Size = new System.Drawing.Size(220, 37);
            this._startServerButton.TabIndex = 0;
            this._startServerButton.Text = "Start Server";
            this._startServerButton.UseVisualStyleBackColor = true;
            this._startServerButton.Click += new System.EventHandler(this.StartServerButtonHandler);
            // 
            // _stopServerButton
            // 
            this._stopServerButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this._stopServerButton.Location = new System.Drawing.Point(3, 251);
            this._stopServerButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this._stopServerButton.Name = "_stopServerButton";
            this._stopServerButton.Size = new System.Drawing.Size(219, 37);
            this._stopServerButton.TabIndex = 1;
            this._stopServerButton.Text = "Stop Server";
            this._stopServerButton.UseVisualStyleBackColor = true;
            this._stopServerButton.Click += new System.EventHandler(this.StopServerButtonHandler);
            // 
            // _portLabel
            // 
            this._portLabel.AutoSize = true;
            this._portLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._portLabel.Location = new System.Drawing.Point(3, 206);
            this._portLabel.Name = "_portLabel";
            this._portLabel.Size = new System.Drawing.Size(219, 41);
            this._portLabel.TabIndex = 2;
            this._portLabel.Text = "Listen on Port:";
            this._portLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this._portLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // _portBox
            // 
            this._portBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._portBox.Location = new System.Drawing.Point(228, 210);
            this._portBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this._portBox.Name = "_portBox";
            this._portBox.Size = new System.Drawing.Size(220, 27);
            this._portBox.TabIndex = 3;
            this._portBox.Text = "100";
            this._portBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // _statusBox
            // 
            this._statusBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._statusBox.Location = new System.Drawing.Point(3, 4);
            this._statusBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this._statusBox.Multiline = true;
            this._statusBox.Name = "_statusBox";
            this._statusBox.ReadOnly = true;
            this.tableLayoutPanel1.SetRowSpan(this._statusBox, 2);
            this._statusBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this._statusBox.Size = new System.Drawing.Size(451, 592);
            this._statusBox.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 600);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private Button _startServerButton;
        private Button _stopServerButton;
        private TextBox _statusBox;
        private Label _portLabel;
        private TextBox _portBox;
        private Label _connectedClientsLabel;
        private TextBox _conncectedClientsBox;
        private Label _questionNumberLabel;
        private TextBox questionBox;
        private Label _ipLabel;
        private TextBox _ipBox;
        private Label label1;
        private Button startGameButton;
    }
}