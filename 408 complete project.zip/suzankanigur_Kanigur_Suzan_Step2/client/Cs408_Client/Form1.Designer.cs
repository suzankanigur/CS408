﻿namespace Cs408_Client
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this._ipBox = new System.Windows.Forms.TextBox();
            this._portBox = new System.Windows.Forms.TextBox();
            this._ipLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this._serverConnectButton = new System.Windows.Forms.Button();
            this._serverDisconnectButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.usernameLabel = new System.Windows.Forms.Label();
            this._inputBox = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.usernameBox = new System.Windows.Forms.TextBox();
            this._inputButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this._ipBox, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this._portBox, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this._ipLabel, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this._serverConnectButton, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this._serverDisconnectButton, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(-3, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75.50274F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.49726F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(443, 718);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.textBox1, 2);
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(437, 459);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // _ipBox
            // 
            this._ipBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._ipBox.Location = new System.Drawing.Point(224, 618);
            this._ipBox.Name = "_ipBox";
            this._ipBox.Size = new System.Drawing.Size(216, 23);
            this._ipBox.TabIndex = 2;
            this._ipBox.Text = "192.168.1.45";
            this._ipBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // _portBox
            // 
            this._portBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._portBox.Location = new System.Drawing.Point(224, 647);
            this._portBox.Name = "_portBox";
            this._portBox.Size = new System.Drawing.Size(216, 23);
            this._portBox.TabIndex = 1;
            this._portBox.Text = "100";
            this._portBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this._portBox.TextChanged += new System.EventHandler(this._portBox_TextChanged);
            // 
            // _ipLabel
            // 
            this._ipLabel.AutoSize = true;
            this._ipLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._ipLabel.Location = new System.Drawing.Point(3, 615);
            this._ipLabel.Name = "_ipLabel";
            this._ipLabel.Size = new System.Drawing.Size(215, 29);
            this._ipLabel.TabIndex = 3;
            this._ipLabel.Text = "IP Address:";
            this._ipLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this._ipLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 644);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "Port Number:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // _serverConnectButton
            // 
            this._serverConnectButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this._serverConnectButton.Location = new System.Drawing.Point(224, 676);
            this._serverConnectButton.Name = "_serverConnectButton";
            this._serverConnectButton.Size = new System.Drawing.Size(216, 39);
            this._serverConnectButton.TabIndex = 5;
            this._serverConnectButton.Text = "Connect to Server";
            this._serverConnectButton.UseVisualStyleBackColor = true;
            this._serverConnectButton.Click += new System.EventHandler(this._serverConnectButton_Click);
            // 
            // _serverDisconnectButton
            // 
            this._serverDisconnectButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this._serverDisconnectButton.Location = new System.Drawing.Point(3, 676);
            this._serverDisconnectButton.Name = "_serverDisconnectButton";
            this._serverDisconnectButton.Size = new System.Drawing.Size(215, 39);
            this._serverDisconnectButton.TabIndex = 6;
            this._serverDisconnectButton.Text = "Disconnect";
            this._serverDisconnectButton.UseVisualStyleBackColor = true;
            this._serverDisconnectButton.Click += new System.EventHandler(this._serverDisconnectButton_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.usernameLabel, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this._inputBox, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 468);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 79.86111F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.13889F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(215, 144);
            this.tableLayoutPanel3.TabIndex = 10;
            // 
            // usernameLabel
            // 
            this.usernameLabel.AutoSize = true;
            this.usernameLabel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.usernameLabel.Location = new System.Drawing.Point(3, 129);
            this.usernameLabel.Name = "usernameLabel";
            this.usernameLabel.Size = new System.Drawing.Size(209, 15);
            this.usernameLabel.TabIndex = 9;
            this.usernameLabel.Text = "Username :";
            this.usernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.usernameLabel.Click += new System.EventHandler(this.usernameLabel_Click);
            // 
            // _inputBox
            // 
            this._inputBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._inputBox.Location = new System.Drawing.Point(3, 3);
            this._inputBox.Multiline = true;
            this._inputBox.Name = "_inputBox";
            this._inputBox.Size = new System.Drawing.Size(209, 109);
            this._inputBox.TabIndex = 8;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.usernameBox, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this._inputButton, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(224, 468);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 79.28571F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20.71428F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(216, 140);
            this.tableLayoutPanel2.TabIndex = 9;
            // 
            // usernameBox
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.usernameBox, 2);
            this.usernameBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.usernameBox.Location = new System.Drawing.Point(3, 114);
            this.usernameBox.Multiline = true;
            this.usernameBox.Name = "usernameBox";
            this.usernameBox.Size = new System.Drawing.Size(210, 23);
            this.usernameBox.TabIndex = 1;
            this.usernameBox.TextChanged += new System.EventHandler(this.usernameBox_TextChanged);
            // 
            // _inputButton
            // 
            this._inputButton.Location = new System.Drawing.Point(3, 3);
            this._inputButton.Name = "_inputButton";
            this._inputButton.Size = new System.Drawing.Size(209, 105);
            this._inputButton.TabIndex = 7;
            this._inputButton.Text = "Send";
            this._inputButton.UseVisualStyleBackColor = true;
            this._inputButton.Click += new System.EventHandler(this._inputButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 742);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private TextBox textBox1;
        private TextBox _ipBox;
        private TextBox _portBox;
        private Label _ipLabel;
        private Label label2;
        private Button _serverConnectButton;
        private Button _serverDisconnectButton;
        private TextBox _inputBox;
        private TableLayoutPanel tableLayoutPanel3;
        private Button _inputButton;
        private TableLayoutPanel tableLayoutPanel2;
        private TextBox usernameBox;
        private Label usernameLabel;
    }
}