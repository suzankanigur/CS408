using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Threading;
using System.IO;
using Cs408_Client.Utils;


namespace Cs408_Client
{
    public partial class Form1 : Form
    {
        //variables
        private IPAddress ip = default!;
        private int port;
        private TcpClient _client = default!;
        private string check = "9";


        public Form1()
        {
            InitializeComponent();
            _serverConnectButton.Enabled = true;
            _serverDisconnectButton.Enabled = false;
            _inputButton.Enabled = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //changes string to IPAddress, default is "192.168.1.45".
        private IPAddress StringToIP(string ip)
        {
            IPAddress temp_ip= IPAddress.Parse("192.168.1.45");

            try
            {
                if(IPAddress.TryParse(ip,out temp_ip))
                {
                    temp_ip = IPAddress.Parse(ip);

                }

            }catch(Exception ex)
            {
                textBox1.Text += "\r\nInvalid IP address entered!";
                textBox1.Text += "\r\n"+ex.ToString();
            }



            return temp_ip;

        }

        //changes string to port(int), default is 100.
        private int StringToPort(string port)
        {
            int temp_port = int.Parse("100");

            try
            {
                if (int.TryParse(port, out temp_port))
                {
                    temp_port = int.Parse(port);

                }

            }
            catch (Exception ex)
            {
                textBox1.Text += "\r\nInvalid Port address entered!";
                textBox1.Text += "\r\n" + ex.ToString();
            }



            return temp_port;

        }
        //Establishes connection to server.
        private void _serverConnectButton_Click(object sender, EventArgs e)
        {
            ip = StringToIP(_ipBox.Text);
            port= StringToPort(_portBox.Text);
            textBox1.InvokeEx(SendBack => SendBack.Text = string.Empty);

            try
            {
                _client = new TcpClient(ip.ToString(), port);
                Thread t = new Thread(ClientConncetion); //Establishes connection thread.
                t.IsBackground= true;
                t.Start(_client);//Starts connection thread.

                _serverConnectButton.Enabled = false;
                _serverDisconnectButton.Enabled = true;
                _inputButton.Enabled = true;


            }
            catch(Exception ex) 
            {
                textBox1.Text += "\r\nProblem Connecting To Server";
                textBox1.Text += "\r\n" + ex.ToString();

            }

        }

        //Establishes connection to the server , Gets the server messages and prints them to the textbox
        private void ClientConncetion(object tcpClient)
        {
            TcpClient client = (TcpClient) tcpClient;
            String input = string.Empty;
            StreamReader reader;
            StreamWriter writer;
            try
            {
                reader = new StreamReader(client.GetStream());
                writer = new StreamWriter(client.GetStream());
                writer.WriteLine("0 " + usernameBox.Text + " connected to the Server");
                writer.Flush();
                

                while (client.Connected)
                {
                    input= reader.ReadLine();
                    


                    if (input == null || input == "Username already taken.")
                    {
                        Disconnect();
                        textBox1.InvokeEx(SendBack => SendBack.Text += "\r\n Server Message: " + "Username already taken.");
                    }
                    else
                    {
                        switch(input)
                        {
                            case "Game Started":
                                {
                                    check = "1";
                                    textBox1.InvokeEx(stb => stb.Text = "\r\n"+input+"\r\n");

                                    break;
                                }
                            case "Game Ended":
                                {
                                    check = "9";
                                    textBox1.InvokeEx(stb => stb.Text = "\r\n" + input + "\r\n");

                                    break;
                                }
                            case "Total Scores:":
                                {
                                    textBox1.InvokeEx(stb => stb.Text = "\r\n" + input + "\r\n");

                                    break;
                                }
                            default:
                                {
                                    textBox1.InvokeEx(SendBack => SendBack.Text += "\r\n"+ input);
                                    break;
                                }
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                textBox1.InvokeEx(stb => stb.Text += "\r\nProblem connecting...\r\n" + ex.ToString());

            }
            _serverConnectButton.InvokeEx(cb => cb.Enabled= true);
            _serverDisconnectButton.InvokeEx(db =>db.Enabled= false);
            _inputButton.InvokeEx(ib => ib.Enabled = false);
        }

        //Disconnects from the server function
        private void Disconnect()
        {
            textBox1.InvokeEx(stb => stb.Text = string.Empty);
            try
            {
                _client.Close();
                _serverConnectButton.InvokeEx(cb => cb.Enabled = false);
                _serverDisconnectButton.InvokeEx(db => db.Enabled = true);
                _inputButton.InvokeEx(ib => ib.Enabled = true);
                textBox1.InvokeEx(stb => stb.Text += "\r\nDisconnected from server.\r\n");


            }
            catch (Exception ex)
            {
                textBox1.InvokeEx(stb => stb.Text += "\r\nCannot disconnect from server.\r\n" + ex.ToString());
            }



        }
        //Disconnects from the server
        private void _serverDisconnectButton_Click(object sender, EventArgs e)
        {

            Disconnect();
           
        }

        //Sends the written string to server
        private void _inputButton_Click(object sender, EventArgs e)
        {

            try
            {
                if(_client.Connected) 
                {
                    StreamWriter writer = new StreamWriter(_client.GetStream());
                    writer.WriteLine(check + _inputBox.Text);
                    writer.Flush();
                    textBox1.Text += "\r\nSent to Server";
                    _inputBox.Text = string.Empty;

                }

            }
            catch (Exception ex)
            {
                textBox1.Text += "\r\nCannot send to Server\r\n" + ex.ToString();

            }

        }

        private void _portBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void usernameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void usernameLabel_Click(object sender, EventArgs e)
        {

        }
    }
}